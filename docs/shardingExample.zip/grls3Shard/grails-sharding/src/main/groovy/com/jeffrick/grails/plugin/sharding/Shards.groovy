package com.jeffrick.grails.plugin.sharding

class Shards {
  static shards = []

  static list() {
    return shards
  }
}
