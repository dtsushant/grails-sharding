package grls3shard


class BookController {
    def shardService
    def sessionFactory

    def index() {
        shardService.change("shard01");
        new Book(author: "someone from shard01",title: "something from shard01").save();

        render Book.list();

        shardService.change("shard02");
        new Book(author: "someone from shard02",title: "something from shard02").save();

        render Book.list();
    }


}
