package grls3shard

class Book {

    String title
    String author

    static constraints = {
    }

    static mapping = {
        datasource "ALL"
    }

    String toString(){
       return "Title ===>> ${this.title}, Author ====>>> ${this.author}"
    }
}
